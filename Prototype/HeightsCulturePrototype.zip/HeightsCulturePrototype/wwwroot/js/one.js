﻿// Animations init
new WOW().init();